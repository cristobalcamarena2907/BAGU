import SwiftUI
import MapKit
import FirebaseFirestore
import FirebaseStorage
import UIKit
import CoreLocation
import Combine

struct ResiduoView: View {
    @StateObject private var viewModel = DonateClothesViewModel()
    @Environment(\.dismiss) var dismiss
    
    var isDescriptionValid: Bool {
        !viewModel.descriptionClothes.isEmpty && viewModel.descriptionClothes.count >= 5
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(.systemGray6) // Fondo claro neutro
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 20) {
                    // Header con logo
                    HStack {
                        Button(action: {
                            dismiss() // Acción para regresar
                        }) {
                            Image("RED-BAMX")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .padding(.top, 10)
                        }
                        Spacer()
                    }
                    .padding(.horizontal)
                    .background(Color.white.shadow(radius: 2)) // Fondo blanco para el header
                    
                    // Título de la página
                    Text("Reportar Ropa")
                        .font(.largeTitle)
                        .bold()
                        .padding(.top, 10)
                    
                    // Picker para elegir tipo de ropa con fondo blanco
                    Picker("Tipo de ropa", selection: $viewModel.clothType) {
                        ForEach(viewModel.clothTypes, id: \.self) { type in
                            Text(type)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()
                    .background(Color.white)
                    .cornerRadius(10)
                    .shadow(radius: 1)
                    
                    // Campo de descripción con sombra sutil
                    TextField("Descripción de la ropa...", text: $viewModel.descriptionClothes)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(10)
                        .shadow(radius: 1)
                        .padding(.horizontal)
                        .onReceive(Just(viewModel.descriptionClothes)) { newValue in
                            let filtered = newValue.filter { $0.isLetter || $0.isWhitespace }
                            if filtered != newValue {
                                viewModel.descriptionClothes = filtered
                            }
                        }
                    
                    // Mensaje de validación en color rojo
                    if !isDescriptionValid {
                        Text("La descripción debe tener al menos 5 caracteres.")
                            .font(.footnote)
                            .foregroundColor(.red)
                    }
                    
                    // Estado de la ubicación
                    Text(viewModel.locationStatus)
                        .font(.body)
                        .padding()
                    
                    // Botón para enviar ubicación con estilo claro
                    Button(action: {
                        viewModel.requestLocation()
                    }) {
                        Text("Enviar Ubicación")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(radius: 1)
                    }
                    .padding(.horizontal)
                    
                    // Mostrar imagen seleccionada
                    if let image = viewModel.image {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 200)
                            .cornerRadius(10)
                            .shadow(radius: 2)
                            .padding(.horizontal)
                    }
                    
                    // Botón para tomar foto con estilo claro
                    Button(action: {
                        viewModel.showImagePicker = true
                    }) {
                        Text("Tomar Foto")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(radius: 1)
                    }
                    .padding(.horizontal)
                    .sheet(isPresented: $viewModel.showImagePicker) {
                        ImagePicker(image: $viewModel.image, sourceType: .camera)
                    }
                    
                    // Botón para enviar donación en verde con estilo claro
                    Button(action: {
                        viewModel.sendDonation()
                    }) {
                        Text("Enviar Donación")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .shadow(radius: 1)
                    }
                    .padding(.horizontal)
                    
                    Spacer() // Asegura que el botón de regresar quede en la parte inferior
                    
                    // Botón para regresar al Dashboard en gris claro
                    Button(action: {
                        dismiss()
                    }) {
                        Text("Regresar al Dashboard")
                            .font(.title3)
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.gray)
                            .cornerRadius(10)
                            .shadow(radius: 1)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
                .padding(.top, 20)
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    let sourceType: UIImagePickerController.SourceType

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker

        init(parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = uiImage
            }

            picker.dismiss(animated: true)
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }

    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker>) {}
}

#Preview {
    ResiduoView()
}
