import SwiftUI
import MapKit

// Estructura Identificable para las coordenadas con nombre y descripción
struct Location: Identifiable {
    let id = UUID() // Genera un ID único para cada instancia
    let name: String
    let description: String
    let coordinate: CLLocationCoordinate2D
}

struct PersonaView: View {
    // Puntos de donación con sus coordenadas y descripciones
    let donationPoints = [
        Location(
            name: "Banco de Alimentos Guadalajara",
            description: "Se pueden donar alimentos no perecederos, excedentes alimenticios, ropa y realizar donaciones económicas.",
            coordinate: CLLocationCoordinate2D(latitude: 20.6189, longitude: -103.3081)
        ),
        Location(
            name: "Universidad Autónoma de Guadalajara (UAG)",
            description: "Donaciones de alimentos no perecederos y participación en programas como 'Uniendo Manos', que apadrina despensas para familias vulnerables.",
            coordinate: CLLocationCoordinate2D(latitude: 20.6747, longitude: -103.3878)
        ),
        Location(
            name: "Catedral Metropolitana de Guadalajara",
            description: "Aceptan donaciones de alimentos no perecederos durante eventos y colectas especiales.",
            coordinate: CLLocationCoordinate2D(latitude: 20.6765, longitude: -103.3470)
        ),
        Location(
            name: "Instituto Tecnológico y de Estudios Superiores de Occidente (ITESO)",
            description: "Recogen alimentos no perecederos a través de campañas organizadas por la comunidad estudiantil.",
            coordinate: CLLocationCoordinate2D(latitude: 20.6146, longitude: -103.3270)
        ),
        Location(
            name: "Plaza Galerías Guadalajara",
            description: "Espacios habilitados para colectas de alimentos no perecederos durante eventos comunitarios.",
            coordinate: CLLocationCoordinate2D(latitude: 20.6614, longitude: -103.3915)
        )
    ]
    
    @Environment(\.dismiss) var dismiss
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 20.659698, longitude: -103.349609), // Centro de Guadalajara
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )
    
    @State private var selectedLocation: Location? = nil // Variable para almacenar la ubicación seleccionada
    
    var body: some View {
        NavigationView {
            VStack {
                // Encabezado con logo
                HStack {
                    Button(action: {
                        dismiss() // Regresa a la vista anterior al tocar el logo
                    }) {
                        Image("RED-BAMX")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 100, height: 100)
                            .shadow(radius: 5)
                    }
                    
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 20)
                
                // El contenido debajo del encabezado es desplazable
                ScrollView {
                    VStack(spacing: 20) {
                        Text("Puntos de Donación")
                            .font(.largeTitle)
                            .foregroundColor(.black)
                            .bold()
                            .padding(.bottom, 10)
                            .multilineTextAlignment(.center)
                        
                        // Mapa con borde y sombra
                        Map(coordinateRegion: $region, interactionModes: .all, showsUserLocation: false, annotationItems: donationPoints) { point in
                            MapAnnotation(coordinate: point.coordinate) {
                                VStack(spacing: 5) {
                                    // Nombre del lugar siempre visible
                                    Text(point.name)
                                        .font(.caption)
                                        .foregroundColor(.black)
                                        .padding(5)
                                        .background(Color.white.opacity(0.8))
                                        .cornerRadius(5)
                                    
                                    // Botón del marcador
                                    Button(action: {
                                        selectLocation(point)
                                    }) {
                                        Image(systemName: "mappin.and.ellipse")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30, height: 30)
                                            .foregroundColor(.red) // Color del logo
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                }
                            }
                        }
                        .frame(width: 350, height: 350)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.gray, lineWidth: 2))
                        .shadow(radius: 5)
                        
                        // Descripción dinámica
                        if let location = selectedLocation {
                            VStack(alignment: .leading, spacing: 10) {
                                Text(location.name)
                                    .font(.title2)
                                    .foregroundColor(.black)
                                    .bold()
                                
                                Text(location.description)
                                    .font(.body)
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                                
                                // Botón para navegar a la ubicación
                                Button(action: {
                                    openMaps(for: location)
                                }) {
                                    Text("Viajar a ubicación")
                                        .font(.title2)
                                        .foregroundColor(.white)
                                        .padding()
                                        .frame(maxWidth: .infinity)
                                        .background(Color.green) // Verde del logo
                                        .cornerRadius(10)
                                        .shadow(radius: 5)
                                }
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .padding(.horizontal)
                        } else {
                            // Texto por defecto cuando no hay una ubicación seleccionada
                            Text("Selecciona un punto en el mapa para ver su descripción.")
                                .font(.body)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal)
                                .padding(.vertical, 10)
                                .background(Color.white.opacity(0.8))
                                .cornerRadius(10)
                                .shadow(radius: 2)
                                .padding(.bottom, 20)
                        }
                    }
                }
                
                // Botón de regresar siempre visible en la parte inferior
                Button(action: {
                    dismiss()
                }) {
                    Text("Regresar")
                        .font(.title2)
                        .foregroundColor(.white)
                        .padding()
                        .frame(width: 250, height: 50)
                        .background(Color.red) // Rojo del logo
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                .padding(.bottom, 20) // Espacio adicional para el botón de regresar
            }
            .navigationBarBackButtonHidden(true)
        }
    }
    
    // Función para seleccionar una ubicación
    private func selectLocation(_ location: Location) {
        selectedLocation = location
        // Opcional: Centrar el mapa en la ubicación seleccionada
        withAnimation {
            region.center = location.coordinate
        }
    }
    
    // Función para abrir Google Maps o Apple Maps
    private func openMaps(for location: Location) {
        let latitude = location.coordinate.latitude
        let longitude = location.coordinate.longitude
        let regionDistance: CLLocationDistance = 1000
        let coordinates = CLLocationCoordinate2DMake(latitude, longitude)
        let regionSpan = MKCoordinateRegion(center: coordinates, latitudinalMeters: regionDistance, longitudinalMeters: regionDistance)
        
        // Intentar abrir en Apple Maps
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = location.name
        mapItem.openInMaps(launchOptions: options)
    }
}

#Preview {
    PersonaView()
}
