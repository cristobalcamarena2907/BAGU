//
//  DeleteAccountView.swift
//  Prototype1
//
//  Created by Cristobal  Camarena on 09/10/24.
//

import SwiftUI
import FirebaseAuth

struct DeleteAccountView: View {
    @ObservedObject var viewModel: AuthenticationViewModel
    @State private var password: String = ""
    @State private var errorMessage: String?
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack(spacing: 20) {
            Text("Confirmar eliminación de cuenta")
                .font(.title)
                .padding(.top, 40)

            SecureField("Introduce tu contraseña", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.horizontal)

            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
                    .font(.caption)
            }

            Button(action: deleteAccount) {
                Text("Eliminar cuenta")
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.red)
                    .cornerRadius(10)
            }
            .padding(.horizontal)
            .padding(.top, 20)

            Spacer()
        }
        .padding()
    }
    func deleteAccount() {
            viewModel.deleteAccount(password: password) { success, error in
                if success {
                    // Cuenta eliminada con éxito, volver a la pantalla de autenticación
                    viewModel.signOut()
                    presentationMode.wrappedValue.dismiss() // Cerrar la vista
                } else {
                    // Mostrar el mensaje de error
                    errorMessage = error
                }
            }
        }
}

struct DeleteAccountView_Previews: PreviewProvider {
    static var previews: some View {
        // Creación de un viewModel simulado para la vista de previsualización
        let authenticationViewModel = AuthenticationViewModel()

        return DeleteAccountView(viewModel: authenticationViewModel)
    }
}
